import json # for printing in json format. if stored as dictionary it would print in single quotes and wont be in json format
import os
if __name__=='__main__':
    dict_={}
    max_=[None,None]
    min_=[None,None]
    filepath=os.path.abspath('.')
    # print(filepath)
    filepath=os.path.join(filepath,'airlines.csv')
    with open(filepath,"r") as f:
        content=f.readlines()
        for i in content[1:]:
            line=i.split(',')
            # print(line[1])
            if line[1][0]=='"':
                j=2
                while j<len(line):
                    if line[j][-1]=='"':
                        val=','.join(x for x in line[1:j+1])
                        break
                    j+=1
            if val[1:-1] in dict_.keys():
                dict_[val[1:-1]]+=1
            else:
                dict_[val[1:-1]]=1
    
    j_dict=json.dumps(dict_,indent=3)
    
    for i in dict_.keys():    
        if (max_[1] is None) or (max_[1]<dict_[i]):
            max_[0]= i
            max_[1]= dict_[i]
        if (min_[1] is None) or (min_[1]>dict_[i]):
            min_[0]= i
            min_[1]= dict_[i]
    # print(dict_) This will print the dictionary but not in json format
    print(j_dict)
    print(max_[0]+':'+str(max_[1]))
    print(min_[0]+':'+str(min_[1]))